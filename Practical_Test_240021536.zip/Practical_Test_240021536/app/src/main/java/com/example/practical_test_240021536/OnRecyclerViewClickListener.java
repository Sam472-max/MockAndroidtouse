package com.example.practical_test_240021536;

import android.view.View;

public interface OnRecyclerViewClickListener {
    void onItemClickListener(View view);

}

