package com.example.practical_test_240021536;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class InsertActivity extends AppCompatActivity {
      Button btnCreate;
      EditText edtName, edtDishes;
    DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_insert);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        btnCreate = findViewById(R.id.btnCreate);
        edtName = findViewById(R.id.edtName);
        edtDishes = findViewById(R.id.edtDishes);
        db=new DatabaseHelper(this);

        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isInserted=db.insertData(edtName.getText().toString(),
                        edtDishes.getText().toString());
                if(isInserted)
                    Toast.makeText(getApplicationContext(),"A new record is created", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(getApplicationContext(), "Data cannot be inserted", Toast.LENGTH_SHORT).show();
                finish();

            }
        });
    }
}