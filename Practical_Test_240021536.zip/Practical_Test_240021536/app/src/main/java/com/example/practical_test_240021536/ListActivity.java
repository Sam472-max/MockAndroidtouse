package com.example.practical_test_240021536;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity {
     Button btnAdd;
    RecyclerView rV;
    DatabaseHelper db;
    MyAdapter myAdapter;
    private List<Module> modules;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_list);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnAdd = findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListActivity.this, InsertActivity.class);
                startActivity(intent);
            }
        });

        rV = findViewById(R.id.rV);
        rV.setLayoutManager(new LinearLayoutManager(this));
        db = new DatabaseHelper(this);
        modules = loadModule();

        myAdapter = new MyAdapter(this,modules);
        rV.setAdapter(myAdapter);
        myAdapter.setItemClickListener(new OnRecyclerViewClickListener() {
            @Override
            public void onItemClickListener(View view) {
                int position = rV.getChildAdapterPosition(view);
                Intent intent = new Intent(ListActivity.this, UpdateDetailsActivity.class);
                intent.putExtra("selectedItem", modules.get(position));
                startActivity(intent);
            }
        });

    }
    private List<Module> loadModule() {
        List<Module> list = new ArrayList<>();
        Cursor cursor = db.getAllData();
        if(cursor!=null && cursor.moveToFirst()){
            do{
                int id = cursor.getInt(cursor.getColumnIndex("ID"));
                String name=cursor.getString(cursor.getColumnIndex("NAME"));
                String dishes= cursor.getString(cursor.getColumnIndex("DISHES"));
                list.add(new Module(id,name, dishes));
            } while (cursor.moveToNext());
        }
        return list;
    }
}