package com.example.practical_test_240021536;

import java.io.Serializable;

public class Module implements Serializable {
    private int id;
    private String name;
    private String dishes;
    public Module(int id, String name, String dishes){
        this.id=id;
        this.name=name;
        this.dishes=dishes;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDishes() {
        return dishes;
    }

    public void setDishes(String dishes) {
        this.dishes = dishes;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
