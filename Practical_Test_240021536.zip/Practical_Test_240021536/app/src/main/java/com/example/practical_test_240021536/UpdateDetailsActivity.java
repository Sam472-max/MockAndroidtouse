package com.example.practical_test_240021536;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class UpdateDetailsActivity extends AppCompatActivity {


    private DatabaseHelper db;
    EditText edtNameU, edtDishesU;
    Button btnUpdate;
    Module module;
    int moduleId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_update_details);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        edtNameU=findViewById(R.id.edtNameU);
        edtDishesU=findViewById(R.id.edtDishesU);
        btnUpdate=findViewById(R.id.btnUpdate);
        db=new DatabaseHelper(this);

        module=(Module) getIntent().getSerializableExtra("selectedItem");

        if (module!=null){
            edtNameU.setText(module.getName());
            edtDishesU.setText(module.getDishes());
        }

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!edtNameU.getText().toString().isEmpty() && !edtDishesU.getText().toString().isEmpty()) {
                    boolean isUpdated = db.updateData(String.valueOf(module.getId()),
                            edtNameU.getText().toString(), edtDishesU.getText().toString());
                    if (isUpdated) {
                        Toast.makeText(getApplicationContext(), "Data updated", Toast.LENGTH_SHORT).show();
                    }
                    Intent intent = new Intent(UpdateDetailsActivity.this, MainActivity.class);
                    startActivity(intent);
                }
            }
        });
    }
}