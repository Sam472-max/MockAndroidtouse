package com.example.practical_test_240021536;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyViewHolder extends RecyclerView.ViewHolder{
//Item inside the RecyclerView

    protected TextView txtItem;
    public MyViewHolder(@NonNull View itemView) {
        super(itemView);
        txtItem=itemView.findViewById(R.id.txtItem);


    }
}
